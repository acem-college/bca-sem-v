﻿namespace WaterQuality.Application
{
    public class Class1
    {

    }
}
