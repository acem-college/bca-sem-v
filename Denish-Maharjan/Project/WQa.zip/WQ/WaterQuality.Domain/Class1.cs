﻿namespace WaterQuality.Domain
{
    public class Class1
    {

    }
}
